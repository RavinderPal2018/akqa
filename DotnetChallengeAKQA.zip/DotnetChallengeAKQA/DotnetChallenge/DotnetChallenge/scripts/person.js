﻿var DotnetChallenge;
DotnetChallenge = window.DotnetChallenge || {};
// Modular Javascript 
DotnetChallenge.Person = (function () {
    "use strict";

    var controller = {};
    // Initialising controls to events
    controller.init = function () {
        $("#btnSubmit").on("click", controller.GetPersonDetails);
    };

    // Get Person Details - call to webapi to get all the data
    controller.GetPersonDetails = function () {
        var personName = $("#txtPersonName").val();
        var personDailyExpense = $("#txtPersonDailyExpense").val();
        if (controller.Validate(personName, personDailyExpense)) {
            $.ajax({
                type: "GET",
                url: "http://localhost:53360/api/Person/GetPerson?name=" + personName + "&amount=" + personDailyExpense, //URI
                dataType: "json",
                success: function (data) {
                    if (data != null && (data.Name != "" || data.Amount != "")) {
                        $("#tblResults").show();
                        $("#lblPersonName").text(data.Name);
                        $("#lblPersonDailyExpense").text(data.Amount);
                    }
                },
                error: function (xhr) {
                    alert(xhr.responseText);
                }
            });
        }
    };

    // Validate name and amount
    controller.Validate = function (personName, personDailyExpense) {
        if (personName == '') {
            alert('Please enter person name;')
            $("#txtPersonName").focus();
            return false;
        }
        if (personDailyExpense == '') {
            alert('Please enter person daily expense;')
            $("#txtPersonDailyExpense").focus();
            return false;
        }
        if (controller.CheckAmount(personDailyExpense) == false) {
            alert('Please enter valid person daily expense (eg. 123.45, 432.12 only 2 digit(s) after decimal) ');
            $("#txtPersonDailyExpense").focus();
            return false;
        }
        return true;
    };

    // check to have numeric amount with 2 digit after decimal
    controller.CheckAmount = function (inputtxt) {
        var decimal = /^[-+]?[0-9]+\.[0-9][0-9]$/;
        var number = /^[-+]?[0-9]+$/;
        if (inputtxt.match(decimal) || inputtxt.match(number)) {
            return true;
        }
        else {
            return false;
        }
    };

    $(controller.init.bind(controller));
    return controller;
}());
