﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DotnetChallenge.Repo;
using DotnetChallenge.Repo.Entities;

namespace DotnetChallenge.Controllers
{
    public class PersonController : ApiController
    {
        /// <summary>
        /// Unity Dependency Injection web api via constructor is used
        /// </summary>
        IPersonRepository _personRepository;
        public PersonController(IPersonRepository personRepository)
        {
            _personRepository = personRepository;
        }

        [HttpGet]
        public Person GetPerson(string name, string amount)
        {
            return _personRepository.GetPerson(name,amount);
        }
      
    }
}